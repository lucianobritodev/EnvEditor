#!/usr/bin/env bash

if [ -d '/opt/enveditor' ]; then
  pkexec --disable-internal-agent env DISPLAY=:0 XAUTHORITY=/run/user/1000/gdm/Xauthority  '/opt/enveditor/bin/EnvEditor' user.home=/home/luciano app.version=v1.3.0
fi

